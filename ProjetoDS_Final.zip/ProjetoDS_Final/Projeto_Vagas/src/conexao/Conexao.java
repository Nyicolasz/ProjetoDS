package conexao;

import controle.Login;
import controle.Menu;
import javax.swing.JOptionPane;
import java.sql.*;

public class Conexao {

    final private String driver = "com.mysql.jdbc.Driver";
    final private String url = "jdbc:mysql://localhost/projeto_ds";
    final private String usuario = "root";
    final private String senha = "";
    private Connection conexao;
    public Statement statement;
    public ResultSet resultset;

    public boolean conecta() {
        boolean result = true;
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, usuario, senha);
            JOptionPane.showMessageDialog(null, "Conexão estabelecida", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        } catch (ClassNotFoundException Driver) {
            JOptionPane.showMessageDialog(null, "Driver não localizado" + Driver, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            result = false;
        } catch (SQLException Fonte) {
            JOptionPane.showMessageDialog(null, "Fonte de Dados não localizada" + Fonte, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            result = false;
        }
        return result;
    }

    public void desconecta() {
        try {
            conexao.close();
            JOptionPane.showMessageDialog(null, "Conexão com banco fechada", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException fecha) {

        }
    }

    public boolean conectaTelas() {
        boolean result = true;
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, usuario, senha);
        } catch (ClassNotFoundException Driver) {
            JOptionPane.showMessageDialog(null, "Driver não localizado" + Driver, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            result = false;
        } catch (SQLException Fonte) {
            JOptionPane.showMessageDialog(null, "Fonte de Dados não localizada" + Fonte, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            result = false;
        }
        return result;
    }

    public boolean Login(String user) {
        try {

            String CodCli = "C_";

            String LoginCli = user;

            String ComparandoCli = LoginCli.substring(0, 3);

            if (CodCli == ComparandoCli) {
                return true;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro " + e, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            e.printStackTrace();

        }

        return false;
    }

    public boolean teste(String username, String password) {

        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, usuario, senha);
            PreparedStatement stmt = conexao.prepareStatement(
                    "SELECT * FROM users WHERE username = ? AND senha = ?");

            stmt.setString(1, username);
            stmt.setString(2, password);

            // 4. Executar consulta
            ResultSet rs = stmt.executeQuery();

            // 5. Processar resultados
            if (rs.next()) {

                return true;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro " + e, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            e.printStackTrace();

        }

        return false;

    }

    public void executaSQL(String sql) {
        try {
            statement = conexao.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            resultset = statement.executeQuery(sql);
        } catch (SQLException excecao) {
            JOptionPane.showMessageDialog(null, "Erro no comando SQL!  \n Erro: " + excecao, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
