-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30/11/2023 às 01:15
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projeto_ds`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `candidato`
--

CREATE TABLE `candidato` (
  `ID_Cand` int(11) NOT NULL,
  `Nome_Cand` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(17) NOT NULL,
  `dt_nasc` varchar(10) NOT NULL,
  `CPF` varchar(13) NOT NULL,
  `rua` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `Estado` varchar(30) NOT NULL,
  `Cidade` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `candidato`
--

INSERT INTO `candidato` (`ID_Cand`, `Nome_Cand`, `email`, `telefone`, `dt_nasc`, `CPF`, `rua`, `bairro`, `Estado`, `Cidade`) VALUES
(1, 'leticia', 'teste@teste.com', '+55 11 1234-56789', '19/10/2023', '123456789-10', 'XXXX', 'XXXX', 'GO - Goiás', 'XXXX'),
(2, 'leticia', 'teste@teste.com', '+55 11 1234-56789', '19/10/2023', '123456789-10', 'XXXXXXXX', 'XXXXX', 'GO - Goiás', 'xXXXX'),
(3, 'Nycolas', 'nycolas@', '+55 11 9778-68414', '09/06/2006', '111111111-11', 'Jetaiba, 39', 'S?o miguel', 'DF - Distrito Federal', 's?o paulo'),
(4, '', '', '+          -     ', '  /  /    ', '         -  ', '', '', 'DF - Distrito Federal', ''),
(5, 'Nycolas Lima Filho', 'nycolaslf2017@gmail.com', '+11 11 1111-11111', '09/06/2006', '999999999-99', 'Rua', 'jardim Helena', 'SP - S?o Paulo', 'S?o Paulo'),
(6, '', '', '+          -     ', '  /  /    ', '         -  ', '', '', 'DF - Distrito Federal', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `candidato_vaga`
--

CREATE TABLE `candidato_vaga` (
  `ID_Cand` int(11) NOT NULL,
  `ID_Vaga` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresa`
--

CREATE TABLE `empresa` (
  `ID_Empresa` int(11) NOT NULL,
  `Nome_Empresa` varchar(30) NOT NULL,
  `CNPJ` varchar(18) NOT NULL,
  `Estado` varchar(2) NOT NULL,
  `Cidade` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `empresa`
--

INSERT INTO `empresa` (`ID_Empresa`, `Nome_Empresa`, `CNPJ`, `Estado`, `Cidade`) VALUES
(1, 'Teste1', '11.111.111/1111-11', 'AC', 'Teste1'),
(2, 'Teste', '11.111.111/1111-11', 'AC', 'Teste');

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresa_vaga`
--

CREATE TABLE `empresa_vaga` (
  `ID_Empresa` int(11) NOT NULL,
  `ID_Vaga` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `ID_users` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `senha` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`ID_users`, `username`, `senha`) VALUES
(1, 'Adm', '123'),
(2, 'C_Nycolas', '456'),
(3, 'E_Empresa', '789'),
(4, 'E_Ray', '999'),
(5, 'E_Ray', '444'),
(6, 'E_Ray', '444');

-- --------------------------------------------------------

--
-- Estrutura para tabela `vagas`
--

CREATE TABLE `vagas` (
  `ID_Vaga` int(11) NOT NULL,
  `N_Vagas` int(25) NOT NULL,
  `Cargo` varchar(20) NOT NULL,
  `Descricao` varchar(100) NOT NULL,
  `Salario` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `vagas`
--

INSERT INTO `vagas` (`ID_Vaga`, `N_Vagas`, `Cargo`, `Descricao`, `Salario`) VALUES
(1, 10, 'Professor', 'Professor de DS', '1000,00');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `candidato`
--
ALTER TABLE `candidato`
  ADD PRIMARY KEY (`ID_Cand`);

--
-- Índices de tabela `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`ID_Empresa`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID_users`);

--
-- Índices de tabela `vagas`
--
ALTER TABLE `vagas`
  ADD PRIMARY KEY (`ID_Vaga`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `candidato`
--
ALTER TABLE `candidato`
  MODIFY `ID_Cand` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `empresa`
--
ALTER TABLE `empresa`
  MODIFY `ID_Empresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `ID_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `vagas`
--
ALTER TABLE `vagas`
  MODIFY `ID_Vaga` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
